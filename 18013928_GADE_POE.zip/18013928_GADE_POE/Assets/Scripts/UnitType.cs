﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitType : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    enum UnitType
    {
        MELEE,RANGED,WIZARD
    }
    enum BuildingType
    {
        FACTORY,RESOURCE
    }
}
